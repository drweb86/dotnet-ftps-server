# Third-party notices

The ftps-server console's own code is dedicated to the public domain under CC0 1.0 Universal. The components listed here are not covered by that dedication. Each remains under the license stated for it. This file is distributed with the console application.

FtpsServerLibrary, which this tool embeds, has no third-party dependencies.

Self-contained builds include the .NET runtime. It is listed with the MIT components.

NLog.Schema is an XML schema used by the IDE. It is not copied into the published application.

## BSD-2-Clause

- **NLog.Extensions.Logging** 6.3.0. Copyright (c) 2004-2026 NLog Project. [https://github.com/NLog/NLog.Extensions.Logging](https://github.com/NLog/NLog.Extensions.Logging)

## BSD-3-Clause

- **NLog** 6.2.2. Copyright (c) 2004-2026 NLog Project. Authors: Jarek Kowalski, Kim Christensen, Julian Verdurmen. [https://nlog-project.org/](https://nlog-project.org/)

## MIT

- **.NET Runtime** 11. Copyright (c) .NET Foundation and Contributors. [https://dot.net/](https://dot.net/)
- **Microsoft.Extensions.Configuration.Abstractions** 11.0.0. © Microsoft Corporation. All rights reserved. [https://dot.net/](https://dot.net/)
- **Microsoft.Extensions.DependencyInjection** 11.0.0. © Microsoft Corporation. All rights reserved. [https://dot.net/](https://dot.net/)
- **Microsoft.Extensions.DependencyInjection.Abstractions** 11.0.0. © Microsoft Corporation. All rights reserved. [https://dot.net/](https://dot.net/)
- **Microsoft.Extensions.Logging** 11.0.0. © Microsoft Corporation. All rights reserved. [https://dot.net/](https://dot.net/)
- **Microsoft.Extensions.Logging.Abstractions** 11.0.0. © Microsoft Corporation. All rights reserved. [https://dot.net/](https://dot.net/)
- **Microsoft.Extensions.Options** 11.0.0. © Microsoft Corporation. All rights reserved. [https://dot.net/](https://dot.net/)
- **Microsoft.Extensions.Primitives** 11.0.0. © Microsoft Corporation. All rights reserved. [https://dot.net/](https://dot.net/)

## BSD 2-Clause License text

Copyright (c) 2004-2026 NLog Project - https://nlog-project.org/

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

## BSD 3-Clause License text

Copyright (c) 2004-2026 NLog Project - https://nlog-project.org/

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

## MIT License text

MIT License

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
